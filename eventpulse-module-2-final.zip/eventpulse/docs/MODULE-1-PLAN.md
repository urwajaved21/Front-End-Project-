# EventPulse — Module 1: Planning & Setup

**Intern:** Muhammad Urwa Javed  **Internship ID:** ZYNVEX-CERT-2192
**Program:** Zynvex Solutions · Batch 5 Virtual Internship · Front End Track
**Module window:** Oct 26 – Nov 01, 2026

---

## 1. What the project does

EventPulse is a campus hackathon and workshop portal. It gives a tech community one place to promote upcoming hackathons, coding bootcamps and guest lectures.

**Problem:** event information is scattered across chats and posters, and sign-ups are slow.

**Users**
| User | What they want |
|---|---|
| Student / participant | Browse the schedule, meet speakers, check seats left, register quickly, add the event to their calendar |
| Organizer | A high-converting event page that turns visitors into registrations |

**Goal:** a responsive, cross-browser portal, deployed live, with a GitHub repo and README.

---

## 2. Pages & features

EventPulse is a **3-page site**. The Home page is a long, scrolling event page; two supporting pages hold the full lists so the Home page stays focused on getting people to register.

| Page | File | Purpose | Reached from |
|---|---|---|---|
| Home | `index.html` | Main conversion page: hero, highlights, agenda, speakers, venue, FAQ, registration | Logo, nav |
| Events | `events.html` | Full list of hackathons, bootcamps and lectures with type filters, seats and Register buttons | Nav, "Browse all events" (hero), "See all events" (About), "Full events list" (Agenda) |
| Speakers | `speakers.html` | Speaker directory with a profile popup per speaker | Nav, "See all speakers" (Home), "Meet the speakers" (Events) |

**Why these two extra pages:** the Events page serves visitors who want to compare events before registering. The Speakers page shows the full line-up without crowding the Home page. Everything else (tabs, accordion, map, registration overlay) stays on the Home page, where it converts best.

**Button flow**
| Button | Goes to |
|---|---|
| Register (nav, hero, cards, CTA bands) | Home → registration section / overlay |
| Browse all events / See all events / Full events list | `events.html` |
| See all speakers / Meet the speakers | `speakers.html` |
| ← Browse all events | back to `events.html` |
| Details (event card) | Home → agenda section |
| View profile (speaker card) | Speaker popup (Module 3) |
| Event type chips | Filter the Events list (Module 3) |

### Sections on the Home page

| # | Section | Features | Built in |
|---|---|---|---|
| 1 | Header / Nav | Logo, anchor links, Register button, mobile menu | M2 (layout), M4 (mobile polish) |
| 2 | Hero | Headline, date and venue, live seat counter, main CTA | M2 / M3 |
| 3 | About / Highlights | Cards for hackathon, bootcamp and guest lecture | M2 |
| 4 | Agenda | **Tabs** per day with session times and titles | M2 (static) / M3 (tabs) |
| 5 | Speakers | Speaker cards, **popup** with bio and links | M2 / M3 |
| 6 | Venue | **Leaflet + OpenStreetMap** map, address, directions link | M3 |
| 7 | FAQ | **Accordion**, one open at a time | M2 / M3 |
| 8 | Registration | **Overlay form**, validation, success state | M3 |
| 9 | Seat counter | **Live seat counters** with Plenty / Filling fast / Sold out states | M3 |
| 10 | Calendar invite | Download an **.ics** file after registering | M3 |
| 11 | Footer | Links, credits | M2 |

### Extra features on the inner pages
| Page | Feature | Built in |
|---|---|---|
| Events | Event cards (type tag, venue, seats, Register button), filter chips, sold-out state, empty state | M2 (static) / M3 (filtering) |
| Speakers | Speaker cards, profile popup, links | M2 / M3 |

**Edge cases to handle:** invalid or empty form fields, duplicate email, sold-out event (disable register), no JavaScript fallback for key content, keyboard access and Escape to close overlays.

---

## 3. Tools & tech stack

| Purpose | Choice | Why |
|---|---|---|
| Structure | HTML5 (semantic) | Accessibility and SEO |
| Styling | CSS3 with custom properties, Grid and Flexbox | No framework needed; tokens keep design consistent |
| Behavior | Vanilla JavaScript (ES6+) | Required by the proposal |
| Map | Leaflet + OpenStreetMap | Free, no API key |
| Data | Local JS/JSON object for sessions, speakers, seats | No backend needed |
| Version control | Git + GitHub | Required deliverable |
| Wireframes | HTML wireframes (`docs/wireframes.html`) | Viewable in any browser |
| Hosting | GitHub Pages (or Netlify) | Free, fast deploy in Module 4 |
| Editor | VS Code + Live Server | Quick preview |

---

## 4. Design decisions

### Colors
| Token | Hex | Use |
|---|---|---|
| `--color-bg` | `#0B1020` | Page background |
| `--color-surface` | `#131A33` | Cards, panels |
| `--color-surface-2` | `#1B2444` | Hover / raised |
| `--color-primary` | `#6B46F5` | Buttons, brand |
| `--color-accent` | `#22D3A6` | Highlights, live counters, success |
| `--color-warning` | `#FFB020` | Seats filling fast |
| `--color-danger` | `#FF5D73` | Sold out, errors |
| `--color-text` | `#E8ECF8` | Main text |
| `--color-text-muted` | `#9AA4C7` | Secondary text |

A dark theme with a violet and teal pair fits a hackathon and developer audience. Text and background contrast is high.

### Fonts
- **Space Grotesk** for headings: techy, friendly
- **Inter** for body text: highly readable
- **JetBrains Mono** for counters and labels: signals "code"

### Layout
- Single column of full-width sections inside a 1120px centered container
- 8px spacing scale; rounded corners (12px)
- Breakpoints: mobile < 640px, tablet 640–1023px, desktop ≥ 1024px
- Mobile-first mindset; full responsive pass in Module 4

---

## 5. Wireframes

See `docs/wireframes.html` (open in a browser). It contains the style tile, page flow, desktop and mobile home layouts, the Events and Speakers page layouts, and the speaker popup, registration form and success overlays.

---

## 6. Project structure

```
eventpulse/
├── index.html          # Home
├── events.html         # All events
├── speakers.html       # Speaker directory
├── css/
│   ├── variables.css   # design tokens
│   ├── base.css        # reset, typography, buttons, cards
│   ├── layout.css      # header, hero, footer, grids
│   ├── components.css  # home page sections (added in Module 2)
│   └── pages.css       # events + speakers page styles
├── js/
│   └── main.js
├── assets/
│   ├── images/
│   └── icons/
├── docs/
│   ├── MODULE-1-PLAN.md
│   └── wireframes.html
├── README.md
└── .gitignore
```

**Git workflow:** `main` holds stable work. Commit small and often with clear messages (`feat:`, `style:`, `docs:`, `fix:`). One commit at the end of each module, tagged `module-1`, `module-2`, and so on.

---

## 7. Module 1 checklist

- [x] Decide what the project does and list pages/features
- [x] Sketch wireframes (desktop, mobile, overlays)
- [x] Pick tools (HTML / CSS / JS, Leaflet) and set up project and Git repo
- [x] Choose colors, fonts and basic layout
- [x] Base HTML skeleton with all section placeholders
- [x] Design tokens and base styles in CSS
- [x] README written
- [x] Events and Speakers pages added and linked with buttons

---

## 8. Roadmap for Modules 2–4

| Module | Dates | Focus |
|---|---|---|
| 2 | Nov 02 – Nov 08 | Header, footer, nav (with mobile menu); Home, Events and Speakers pages with real static content; base styling |
| 3 | Nov 09 – Nov 15 | Agenda tabs, speaker popups, FAQ accordion, registration overlay and validation, live seat counters, calendar invite, Leaflet map |
| 4 | Nov 16 – Nov 22 | Responsive pass, cross-browser testing, cleanup and performance, deploy, final README |

**Risks and mitigation**
- *Map or API fails to load* → show a static address and directions link as fallback.
- *Time crunch in Module 3* → build the registration overlay and seat counter first; they are the core value.
- *Browser differences* → test in Chrome, Firefox, Safari and Edge during Module 4.
